#include "keepkey/variant/keepkey.h"

#include "keepkey/board/timer.h"
#include "keepkey/board/variant.h"

const VariantInfo variant_keepkey = {
    VARIANTINFO_KEEPKEY
};

