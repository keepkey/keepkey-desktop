# Index

* [How to Build](Build.md)
* [Storage Layout](Storage.md)
* [Supported Coins](Coins.md)
* [Host Communications](Host.md)
