#include "keepkey/board/variant.h"

