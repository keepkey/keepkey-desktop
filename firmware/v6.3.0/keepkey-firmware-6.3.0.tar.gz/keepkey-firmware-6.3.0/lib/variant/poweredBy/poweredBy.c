
#include "keepkey/variant/poweredBy.h"

#include "keepkey/board/timer.h"
#include "keepkey/board/variant.h"

const VariantInfo variant_poweredBy = {
    VARIANTINFO_POWERED_BY
};

