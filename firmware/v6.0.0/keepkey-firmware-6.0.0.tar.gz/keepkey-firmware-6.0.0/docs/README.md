# Index

* [How to Build](https://github.com/keepkey/keepkey-firmware/blob/master/docs/Build.md)
* [Storage Layout](https://github.com/keepkey/keepkey-firmware/blob/master/docs/Storage.md)
* [Supported Coins](https://github.com/keepkey/keepkey-firmware/blob/master/docs/Coins.md)
