#ifndef KEEPKEY_EMULATOR_SETUP_H
#define KEEPKEY_EMULATOR_SETUP_H

void setup(void);

#endif
