#include "keepkey/board/variant.h"

bool variant_isMFR(void) {
    return true;
}
