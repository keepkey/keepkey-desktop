#include "keepkey/variant/salt.h"

#include "keepkey/board/timer.h"
#include "keepkey/board/variant.h"

const VariantInfo variant_salt = {
    VARIANTINFO_SALT
};

