#!/bin/sh
set -e

python ./scripts/emulator/bridge.py &
./bin/kkemu
