#ifndef LIB_FIRMWARE_U2F_H
#define LIB_FIRMWARE_U2F_H

#include <inttypes.h>

const char *words_from_data(const uint8_t *data, int len);

#endif
